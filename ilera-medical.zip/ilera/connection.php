<?php

    $database= new mysqli("localhost","root","","ilera");
    if ($database->connect_error){
        die("Connection failed:  ".$database->connect_error);
    }

?>